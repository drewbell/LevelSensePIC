// prototypes for test event checkers
#include "UART_RX_SM.h"
#include "LevelSensor.h"
// #defines that go with the Event Checkers



